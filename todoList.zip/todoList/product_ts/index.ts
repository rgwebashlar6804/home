let Swal: any;
interface data {
    id: number;
    name: string;
    dueDate: string;
    priority: string;
    image: string | null | undefined | ArrayBuffer;
    creaeAt: string;
    status: string;
}

let todoDetails: data[] = localStorage.getItem("todoDetails") as string ? JSON.parse(localStorage.getItem("todoDetails") as string) : [];

const nameInput = document.getElementById('name') as HTMLInputElement;
const dueDateInput = document.getElementById('due-date') as HTMLInputElement;
const priorityInput = document.getElementById('priority') as HTMLInputElement;
const image = document.getElementById('image') as HTMLInputElement;

const nameError = document.getElementById('name-error-msg') as HTMLSelectElement;
const dueDateError = document.getElementById('due-date-error-msg') as HTMLInputElement;
const priorityError = document.getElementById('priority-error-msg') as HTMLInputElement;
const imageError = document.getElementById('image-error-msg') as HTMLInputElement;

const formselect = document.getElementById("addTodoModal") as HTMLInputElement;

const curdTable = document.querySelector("#curd-table") as HTMLSelectElement;
const sortTable = document.querySelector("#sort-table") as HTMLSelectElement;



const nameEditInput = document.getElementById('edit-name') as HTMLInputElement;
const dueDateEditInput = document.getElementById('edit-due-date') as HTMLInputElement;
const priorityEditInput = document.getElementById('edit-priority') as HTMLInputElement;
const imageEdit = document.getElementById('edit-image') as HTMLInputElement;
const update = document.querySelector("#update") as HTMLSelectElement;
console.log('====================================');
console.log(update);
console.log('====================================');
// const selectElem = document.querySelector("#sort-select") as HTMLInputElement;

function validateForm(): void | boolean {

    const name = _.trim(nameInput.value);
    const dueDate = dueDateInput.value;
    const priority = priorityInput.value;

    if (_.eq(name, "")) {
        nameError.innerHTML = "Please enter your name";
        // return false;
    } else {
        nameError.innerHTML = "";
    }

    if (_.eq(dueDate, "")) {
        dueDateError.innerHTML = "Please enter your Due Date";
        // return false;
    } else {
        dueDateError.innerHTML = "";
    }

    if (_.eq(priority, "")) {
        priorityError.innerHTML = "Please Select Priority";
        // return false;
    } else {
        priorityError.innerHTML = "";
    }


    //image validation
    const allowedExtensions = /(\.jpg|\.jpeg|\.png|\.gif)$/i;
    if (!image.files || _.eq(image.files.length, 0) || !allowedExtensions.test(image.files[0].name)) {
        imageError.innerHTML = "Please attach a valid image file (jpg, jpeg, png, or gif)";
        image.value = "";
        return false;
    } else {
        imageError.innerHTML = "";
    }


    let fileSize = _.divide(image.files[0].size, 1024); // in 1KB
    if (_.gt(fileSize, 1024)) {
        imageError.innerHTML = " Please attach an image that is smaller than 1024KB";
        image.value = "";
        return false;
    }
    else {
        imageError.innerHTML = "";
    }
    return true;
}

function clearForm(): any {
    let formselect = document.getElementById("addTodoModal") as HTMLInputElement;
    formselect.addEventListener('hidden.bs.modal', function () {
        let form = formselect.querySelector('form');
        // Reset the form
        if (form) {
            form.reset();
            let clearError = document.querySelectorAll('.clearError');
            _.forEach(clearError, (element) => {
                element.innerHTML = "";
            });
        }
    });
}


function AddData(): void {
    if (_.isEqual(validateForm(), true)) {
        let id: number = 1;
        let name = nameInput.value as string;
        let dueDate = dueDateInput.value as string;
        let priority = priorityInput.value as string;
        let image: any = document.getElementById("image");
        let creaeAt = new Date() as Date;
        let month = `${creaeAt.getMonth() + 1}` as string;
        let date = `${creaeAt.getDate()}` as string;
        if (month.length < 2) {
            month = `0${month}`;
        }
        if (date.length < 2) {
            date = `0${date}`;
        }
        // console.log('====================================');
        // console.log(date.length);
        // console.log('====================================');

        // return false;
        let newCreateDate = `${creaeAt.getFullYear()} -${month} - ${date}`;
        let status = "pending" as string;
        let reader: FileReader = new FileReader();
        if (_.gt(todoDetails.length, 0)) {
            let ids = _.map(todoDetails, (task) => task.id as number);
            id = _.add(Math.max(...ids), 1);
        }
        reader.readAsDataURL(image.files[0]);
        reader.addEventListener("load", () => {
            const newTask = _.concat(todoDetails, {
                id: id,
                name: name,
                dueDate: dueDate,
                priority: priority,
                creaeAt: newCreateDate,
                image: reader.result,
                status: status,
            });
            localStorage.setItem("todoDetails", JSON.stringify(newTask));
            location.reload();
            // Swal.fire({
            //     // position: "top-end",
            //     icon: "success",
            //     title: "Product Add SuccessFully",
            //     showConfirmButton: false,
            //     timer: 1000
            // }).then(() => {
            //     location.reload();
            // });
        })
    }
}


function showData(): void {
    notes(todoDetails);
}
showData();


function notes(todoDetails: data[]): void {
    let html = "";
    if (_.eq(todoDetails.length, 0)) {
        html += `<div class="card-body">
            <div class="row gx-2">
            <div class="col">
                <div class="p-3">
                <img src="img/no-data-found.png" class="img-fluid rounded mx-auto d-block" alt="No Tasks">
                <p class="text-center">No  to display</p>
                </div>
            </div>
            </div>
        </div>`;
    } else {
        _.forEach(todoDetails, (element) => {
            html += `<tr class="${element.priority} ${element.status}" >
                      <th scope="row">${element.id}</th>
                      <th><img src="${element.image}" class="rounded" height="100" width="100" alt="${element.name}" /></th>
                      <td>${element.name}</td>

                      <td>${element.priority}</td>
                      <td>${element.dueDate}</td>
                      <td>${element.creaeAt}</td>
                      <td>${element.status}</td>
                      <td>
                        <a onclick='editData("${element.id}")' type='button' data-bs-toggle='modal' data-bs-target='#editTodoModal' class='btn btn-success' ><i class="fa-regular fa-pen-to-square"></i></a>
                        <a onclick='deleteData("${element.id}")' type='button' class='btn btn-danger' ><i class="fa-solid fa-trash"></i></a>
                        <a onclick='complateTask("${element.id}")' type='button' class='btn btn-warning' ><i class="fa-solid fa-check-to-slot"></i></a>
                      </td>
                    </tr>
          `
        })
    }
    curdTable.classList.add("d-none");
    curdTable.innerHTML = html;
    // sortTable.innerHTML = html;
}


function deleteData(id: number): void {
    const index = _.findIndex(todoDetails, (task => task.id == id));
    console.log(id);

    if (_.gte(index, 0)) {
        if (confirm("Are you sure you want to delete this item?")) {
            todoDetails.splice(index, 1);
            localStorage.setItem("todoDetails", JSON.stringify(todoDetails));
            showData();
            location.reload(); // Reload the current page
        }

    }
}

function editData(id: number): void {
    const index = _.findIndex(todoDetails, (task => task.id == id));
    if (!(_.isUndefined(index)) && !(_.eq(index, -1)) && todoDetails && _.gt(todoDetails.length, 0)) {
        // if (idEditInput && nameEditInput && dueDateEditInput && priorityEditInput && imageEdit) {
            console.log("eww")
            nameEditInput.value = todoDetails[index].name;
            dueDateEditInput.value = todoDetails[index].dueDate;
            priorityEditInput.value = todoDetails[index].priority;
            const imagePreview = document.getElementById("image-div") as HTMLImageElement;
            const imageDiv = document.getElementById("image-div") as HTMLImageElement;
            const imageEdit = document.getElementById("image-edit") as HTMLImageElement;

            // image edit start
            // if (imagePreview && imageDiv && imageEdit) {
                (imagePreview.src as any) = todoDetails[index].image;
                // document.getElementById('preview-img')?.setAttribute('src',`"${todoDetails[index].image}"`);
                imageDiv.innerHTML = `<img src="${todoDetails[index].image}" width="100%" height="100%">`;
                imageEdit.onchange = function (event) {
                    const file = (event.target as HTMLInputElement | any).files[0];
                    const reader = new FileReader();
                    reader.onload = function () {
                        todoDetails[index].image = reader.result as string;
                        imagePreview.src = reader.result as string;
                    };
                    reader.readAsDataURL(file);
                };
            // }
            update.onclick = function() {
                if (!(_.isUndefined(index)) && !(_.eq(index, -1))) {
                    todoDetails[index].name = nameEditInput.value;
                    todoDetails[index].dueDate = dueDateEditInput.value;
                    todoDetails[index].priority = priorityEditInput.value;
                    localStorage.setItem("todoDetails", JSON.stringify(todoDetails));
                    location.reload();
                    showData();
                }
                
                nameEditInput.value = "";
                dueDateEditInput.value = "";
                priorityEditInput.value = "";
                
                document.getElementById("close-btn")?.click();
            }
        // }
    }
}


function complateTask(id :number) :void{
    const index = _.findIndex(todoDetails, (task => task.id == id));
    todoDetails[index].status = "completed";
    localStorage.setItem("todoDetails", JSON.stringify(todoDetails));
    showData();
    location.reload();

}